import React from 'react'

export default function Header() {
    return (
        <header style={headerStyle}>
            <h1>github</h1>
            <input style={{width:'80%'}}></input>
        </header>
    )
}
const headerStyle= {
    background:'#333',
    color:'#fff',
    padding:'10px',
}