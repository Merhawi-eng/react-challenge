
import React from 'react'

export default function Header() {
    return (
        <div>
            <header style={headerStyle}>
                <h1>github</h1>
                <input style={{width:'80%'}} />
                <button >search</button>
            </header>
        </div>
    )
}

const headerStyle= {
    background:'#333',
    color:'#fff',
    padding:'10px',
}