
import './App.css';
import React, { Component } from 'react'
import Header from './components/Header'
import axios from 'axios' ;

export default class App extends Component {
  constructor(props){
    super(props);
    this.state={
      search:{},
      repoList:[]
    }   
  }

  componentDidMount= () =>{
        axios.get('http://api.github.com/users/abude?client_id=13f4218b30956bfd33602&client_secret=75fd79be77e85d189ff544c0a333322a8110165c &sort=created')
        .then((response)=>{
          this.setState({
            search: response.data
           
          })
        }).catch((error)=>{
          console.log(error)
        })

        axios.get('http://api.github.com/users/abude/repos?client_id=13f4218b30956bfd33602&client_secret=75fd79be77e85d189ff544c0a333322a8110165c &sort=created')
        .then((response)=>{
          this.setState({
            repoList: response.data
            
          })
        }).catch((error)=>{
          console.log(error)
        })
  }

  render() {
    
    const {name,login,location,email}=this.state.search
    return (
      <div style={{margin:'10px'}}>
        <Header/>
         
        <div className="user-data" style={{display:'flex'}}>
          <img src={this.state.search.avatar_url} alt="user"/>
          <div className="personal-data" >
            <p style={dataStyle}>Fullname: {name} </p>
            <p style={dataStyle}>Username: {login} </p>
            <p style={dataStyle}>Location: {location}</p>
            <p style={dataStyle}>Email Address: {email}</p>
          </div>
        </div>
        <h4 style={{color:'blue'}}>User Repositories</h4>
        
        {this.state.repoList.map(value =>{
          return(
            <p style={dataStyle} key={value.id}>{value.name} : {value.description}</p> 

          )
        })}  
      </div>
    )
  }
}
const dataStyle= {
  border: '1px lightgray solid',
  margin: '0 10px',
  padding: '10px',
  
}

